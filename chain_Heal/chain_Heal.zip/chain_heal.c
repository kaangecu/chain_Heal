    #include<stdio.h>

    #include<stdlib.h>

    #include<string.h>

    #include<math.h>

    #include <unistd.h>



    struct node{

            int X, Y;

            int cur_PP, max_PP;

            char *name;



            struct node *next;

            int visited;

	    int nodeNum;



            struct node *gidilecek;



            int healing;

        };



    int node_counter;    



    int initial_range, jump_range, num_jumps, initial_power;

    double power_reduction ;









    struct node *first;

    struct node *current;

    struct node *temp;

    struct node *next;







void hesapla(double G[node_counter][node_counter]);



int main(int argc,char* argv[]){

	





	initial_range = atof(argv[1]);

 	jump_range = atof(argv[2]);

 	num_jumps = atof(argv[3]);

	initial_power = atof(argv[4]);

    	power_reduction = atof(argv[5]);








        first = (struct node*) malloc(sizeof(struct node));

        current = (struct node*) malloc(sizeof(struct node));

        first = NULL;



        int x, y, cur_PP, max_PP;

        char *name = malloc(sizeof(char) * 100);



	FILE *f = stdin;

         node_counter = 0;





    while (fscanf(f, "%d %d %d %d %s", &x, &y, &cur_PP, &max_PP, name) != EOF){

            



       	    temp = (struct node*) malloc(sizeof(struct node));

            temp->X = x;

            temp->Y = y;

            temp->cur_PP = cur_PP;

            temp->max_PP = max_PP;

            temp->name = malloc(sizeof(char) * 100);

            strcpy(temp->name, name);

            temp->nodeNum = node_counter;	    



            if(node_counter <= 0){

                first = temp;

                first->next = NULL;

                current = first;

            }else{

                current->next = temp;

                current = temp;

                current->next = NULL;

            }



            node_counter++;

        }



            fclose(f);







	double G[node_counter][node_counter];

 	int i,j;	



	current = first;

	temp=first;

	for(i=0;i<node_counter;i++)

	{

		for(j=0;j<node_counter;j++)

		{	

			

			G[i][j] = sqrt((current->X - temp->X)*(current->X - temp->X) + 

			(current->Y - temp->Y)*(current->Y - temp->Y));

	temp=temp->next;



		}

		current=current->next;

		temp=first;

	}







next=first;

	hesapla(G);

current->gidilecek = NULL;







int gerekliCan =0, toplamIyilestirme =0;



current = first;



for(int i=0;i<num_jumps;i++)

{

	if(current->gidilecek==NULL) break;

	gerekliCan = (current->gidilecek->max_PP - current->gidilecek->cur_PP);



if(gerekliCan !=0)

{

	if(gerekliCan<initial_power)

	{

		current->gidilecek->healing = gerekliCan;

		toplamIyilestirme+=gerekliCan;

		initial_power = rint(initial_power * (1-power_reduction));

		

	}

	else if ( gerekliCan>initial_power )

	{

		current->gidilecek->healing =  initial_power;

		toplamIyilestirme+=initial_power;

		initial_power = rint(initial_power * (1-power_reduction));

		

	}

}	







            printf("%s  %d  \n",  current->name, current->gidilecek->healing);





            current = current->next;

        }



printf("Toplam_İyileşme %d \n", toplamIyilestirme);







    return 0;

}











void hesapla(double G[node_counter][node_counter])

{

	double enKisaYol=99999;

	current = next;

current->visited = 1;



        



	temp = first;

        while(temp){

	    

		if(G[current->nodeNum][temp->nodeNum] !=0 && enKisaYol>G[current->nodeNum][temp->nodeNum] && temp->visited != 1  )	

		{

					

					enKisaYol=G[current->nodeNum][temp->nodeNum];

					next=temp;

		}

		

            temp = temp->next;

        }

	

	if((current == first && initial_range>=enKisaYol) || jump_range>=enKisaYol)

	    if(next->visited	!= 1)

		{

			current->gidilecek = next;

			hesapla(G);

		}


}









































